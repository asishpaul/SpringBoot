package org.cap.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cap.model.Product;

@Repository("inventoryDao")
@Transactional
public interface IInventoryDao extends JpaRepository<Product,Integer>{

	
}
