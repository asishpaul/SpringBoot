package com.cap.service;

import java.util.List;

import com.cap.model.Product;

public interface IInventoryService {

	public List<Product> saveProduct(Product product);
	public List<Product> getAllProducts();
}
