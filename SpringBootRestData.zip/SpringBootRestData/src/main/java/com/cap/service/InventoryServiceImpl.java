package com.cap.service;

import java.util.List;

import org.cap.dao.ICustomerDao;
import org.cap.dao.IInventoryDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.model.Product;

@Service("inventoryService")
public class InventoryServiceImpl implements IInventoryService{

	@Autowired
	private IInventoryDao inventoryDao;
	@Autowired
	private ICustomerDao customerDao;
	
	@Override
	public List<Product> saveProduct(Product product) {
		
		inventoryDao.save(product);
		return inventoryDao.findAll();
	}

	@Override
	public List<Product> getAllProducts() {
		
		return inventoryDao.findAll();
	}

}
