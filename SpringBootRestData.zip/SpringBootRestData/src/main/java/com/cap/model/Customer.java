package com.cap.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties("hibernateLazyInitializer")
public class Customer {

	@Id
	private int customerId;
	private String customerName;
	
	@ManyToMany(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	@JsonIgnoreProperties("customers")
	@JoinTable(name="products_customers",joinColumns= {@JoinColumn(name="customerId")},
	inverseJoinColumns= {@JoinColumn(name="productId")})
	private List<Product> products;
	
	public Customer() {}

	public Customer(int customerId, String customerName, List<Product> products) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.products = products;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", products=" + products + "]";
	}
	
	
	
}
